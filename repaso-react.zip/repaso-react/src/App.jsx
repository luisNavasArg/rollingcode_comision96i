import './App.css'
import {BrowserRouter,Routes,Route} from 'react-router-dom';
import Menu from './components/Menu';
import Home from './views/Home';
import About from './views/About';
import Contact from './views/Contac';
import Admin from './views/Admin';

function App() {
  

  return (
    <>
    
    <BrowserRouter> 
    <Menu/>
      <Routes>
        <Route path='/' element={<Home/>}/>
        <Route path='/about' element={<About/>}/>
        <Route path='/contact' element={<Contact/>}/>
        <Route path='/admin' element={<Admin/>}/>
      </Routes>
    </BrowserRouter>
    </>
  )
}

export default App
